sélectionnés# Template pour : Quêtes  PHP Cookies & Sessions

Ce Template html va te permettre de réaliser ta quête sur la gestion des cookies et des sessions avec PHP.

Sont inclus :

* la page de connexion,
* la page des produits disponibles a l'achat,
* la page panier, affichant à partir des cookies les produits sélectionnés par l'utilisateur.

Tu n'as que du script PHP à fournir !

Après, si l'envie te prend de refondre le CSS, nous ne ferons rien pour t'en empêcher !
