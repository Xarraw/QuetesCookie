<?php require 'inc/head.php'; 
	if (empty($_SESSION['loginname'])){
  header('Location:login.php');
}
?>
<section class="cookies container-fluid">
    <div class="row">
     <?php
 
if (isset($_COOKIE['cookie'])) {
    foreach ($_COOKIE['cookie'] as $name => $value) {
        $name = htmlspecialchars($name);
        $value = htmlspecialchars($value);
        echo "$value <br />\n";
    }
}

    
     	?>
    </div>
    <button type="button" class="btn btn-default">Clear cart
    	<?php

    	?>
    </button>
</section>
<?php require 'inc/foot.php'; ?>
